import { useEffect, useState } from 'react';
import { Droplets, TrendingUp, Award, Target, Clock } from 'lucide-react';
import { StorageService } from '../services/StorageService';
import { DashboardService } from '../services/DashboardService';
import { WaterGlass } from './WaterGlass';
import { motion } from 'motion/react';

interface DashboardProps {
  userId: string;
}

export function Dashboard({ userId }: DashboardProps) {
  const [dailySummary, setDailySummary] = useState<any>(null);
  const [weeklySummary, setWeeklySummary] = useState<any>(null);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, [userId]);

  const loadData = () => {
    const today = new Date().toISOString().split('T')[0];
    setDailySummary(DashboardService.getDailySummary(userId, today));
    setWeeklySummary(DashboardService.getWeeklySummary(userId));
    setProfile(StorageService.getProfile(userId));
  };

  if (!dailySummary || !profile) return null;

  const percentage = Math.min((dailySummary.totalMl / profile.dailyTargetMl) * 100, 100);
  const streak = weeklySummary.daysMetTarget;

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-gray-900 dark:text-white mb-1">Welcome back, {profile.name}! 👋</h1>
          <p className="text-gray-600 dark:text-gray-400">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
      </motion.div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Water Glass Visualization */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
          style={{ transform: 'perspective(1000px) rotateY(-2deg)' }}
        >
          <h2 className="text-gray-900 dark:text-white mb-6 flex items-center gap-2">
            <Target className="w-6 h-6 text-blue-500" />
            Today's Progress
          </h2>
          <WaterGlass percentage={percentage} />
          <div className="mt-6 text-center">
            <p className="text-4xl text-gray-900 dark:text-white mb-1">
              {dailySummary.totalMl} <span className="text-2xl text-gray-500">ml</span>
            </p>
            <p className="text-gray-600 dark:text-gray-400">
              of {profile.dailyTargetMl} ml goal
            </p>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-blue-500 to-cyan-400 rounded-3xl p-6 shadow-2xl text-white"
            style={{ transform: 'perspective(1000px) rotateY(2deg)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <Droplets className="w-6 h-6" />
              </div>
              <span className="text-3xl">{dailySummary.entries}</span>
            </div>
            <p className="text-white/80">Times Hydrated Today</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-purple-500 to-pink-400 rounded-3xl p-6 shadow-2xl text-white"
            style={{ transform: 'perspective(1000px) rotateY(2deg)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <Award className="w-6 h-6" />
              </div>
              <span className="text-3xl">{streak} 🔥</span>
            </div>
            <p className="text-white/80">Day Streak</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-orange-500 to-yellow-400 rounded-3xl p-6 shadow-2xl text-white"
            style={{ transform: 'perspective(1000px) rotateY(2deg)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <TrendingUp className="w-6 h-6" />
              </div>
              <span className="text-3xl">{weeklySummary.avgMl}</span>
            </div>
            <p className="text-white/80">Weekly Average (ml)</p>
          </motion.div>
        </div>
      </div>

      {/* Recent Activity */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <h2 className="text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Clock className="w-6 h-6 text-blue-500" />
          Recent Activity
        </h2>
        <div className="space-y-3">
          {dailySummary.recentEntries.length === 0 ? (
            <p className="text-gray-500 dark:text-gray-400 text-center py-8">
              No water logged yet today. Start tracking!
            </p>
          ) : (
            dailySummary.recentEntries.map((entry: any, index: number) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-2xl hover:shadow-lg transition-all duration-300"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-xl flex items-center justify-center shadow-lg">
                  <Droplets className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-gray-900 dark:text-white">{entry.amountMl} ml</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {new Date(entry.timestamp).toLocaleTimeString('en-US', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                </div>
                {entry.note && (
                  <p className="text-sm text-gray-600 dark:text-gray-400 italic">"{entry.note}"</p>
                )}
              </motion.div>
            ))
          )}
        </div>
      </motion.div>
    </div>
  );
}
