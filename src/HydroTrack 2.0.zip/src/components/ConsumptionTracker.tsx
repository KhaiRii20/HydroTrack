import { useState } from 'react';
import { Droplets, Plus, Coffee, Beer, Milk } from 'lucide-react';
import { StorageService } from '../services/StorageService';
import { motion } from 'motion/react';

interface ConsumptionTrackerProps {
  userId: string;
}

const quickAmounts = [
  { amount: 250, label: '250ml', icon: '🥤' },
  { amount: 500, label: '500ml', icon: '💧' },
  { amount: 750, label: '750ml', icon: '🍶' },
  { amount: 1000, label: '1L', icon: '🚰' },
];

export function ConsumptionTracker({ userId }: ConsumptionTrackerProps) {
  const [customAmount, setCustomAmount] = useState('');
  const [note, setNote] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const addEntry = (amountMl: number) => {
    const entry = {
      id: crypto.randomUUID(),
      userId,
      timestamp: new Date().toISOString(),
      amountMl,
      note: note.trim(),
    };

    StorageService.saveEntry(entry);
    setNote('');
    setCustomAmount('');
    
    // Show success animation
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);

    // Dispatch custom event for dashboard refresh
    window.dispatchEvent(new CustomEvent('waterAdded'));
  };

  const handleCustomAdd = () => {
    const amount = parseInt(customAmount);
    if (amount > 0 && amount <= 5000) {
      addEntry(amount);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Success Animation */}
      {showSuccess && (
        <motion.div
          initial={{ opacity: 0, y: -50, scale: 0.5 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0 }}
          className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50"
        >
          <div className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white px-8 py-6 rounded-3xl shadow-2xl flex items-center gap-4">
            <Droplets className="w-12 h-12" />
            <div>
              <p className="text-2xl">Great job! 💧</p>
              <p className="text-sm text-white/80">Water logged successfully</p>
            </div>
          </div>
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-gray-900 dark:text-white mb-2">Add Water Intake</h1>
        <p className="text-gray-600 dark:text-gray-400">Track your hydration throughout the day</p>
      </motion.div>

      {/* Quick Add Buttons */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <h2 className="text-gray-900 dark:text-white mb-6">Quick Add</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {quickAmounts.map((item, index) => (
            <motion.button
              key={item.amount}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => addEntry(item.amount)}
              className="bg-gradient-to-br from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white rounded-2xl p-6 shadow-lg transition-all duration-300"
              style={{ transform: 'perspective(500px) rotateY(-5deg)' }}
            >
              <div className="text-4xl mb-2">{item.icon}</div>
              <p className="text-lg mb-1">{item.label}</p>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Custom Amount */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.3 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <h2 className="text-gray-900 dark:text-white mb-6">Custom Amount</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
              Amount (ml)
            </label>
            <input
              type="number"
              value={customAmount}
              onChange={(e) => setCustomAmount(e.target.value)}
              placeholder="Enter amount in ml"
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
              min="1"
              max="5000"
            />
          </div>
          
          <div>
            <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
              Note (optional)
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g., Morning coffee, After workout..."
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
            />
          </div>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleCustomAdd}
            disabled={!customAmount || parseInt(customAmount) <= 0}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white py-4 rounded-xl shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all duration-300 hover:shadow-2xl"
          >
            <Plus className="w-5 h-5" />
            Add Water
          </motion.button>
        </div>
      </motion.div>

      {/* Tips */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 dark:from-purple-500/20 dark:to-pink-500/20 backdrop-blur-xl rounded-3xl p-6 border border-purple-200 dark:border-purple-700"
      >
        <h3 className="text-gray-900 dark:text-white mb-3 flex items-center gap-2">
          💡 Hydration Tips
        </h3>
        <ul className="space-y-2 text-gray-700 dark:text-gray-300 text-sm">
          <li>• Drink a glass of water when you wake up</li>
          <li>• Keep a water bottle with you throughout the day</li>
          <li>• Drink water before, during, and after exercise</li>
          <li>• Set reminders to drink water regularly</li>
        </ul>
      </motion.div>
    </div>
  );
}
