import { useState, useEffect } from 'react';
import { User, Save } from 'lucide-react';
import { StorageService } from '../services/StorageService';
import { motion } from 'motion/react';

interface ProfileSettingsProps {
  userId: string;
}

const activityLevels = [
  { value: 'sedentary', label: 'Sedentary', description: 'Little or no exercise' },
  { value: 'light', label: 'Light', description: 'Exercise 1-3 times/week' },
  { value: 'moderate', label: 'Moderate', description: 'Exercise 4-5 times/week' },
  { value: 'active', label: 'Active', description: 'Daily exercise or intense exercise 3-4 times/week' },
  { value: 'very_active', label: 'Very Active', description: 'Intense exercise 6-7 times/week' },
];

export function ProfileSettings({ userId }: ProfileSettingsProps) {
  const [profile, setProfile] = useState<any>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const loadedProfile = StorageService.getProfile(userId);
    if (loadedProfile) {
      setProfile(loadedProfile);
    }
  }, [userId]);

  const calculateTarget = () => {
    if (!profile) return;
    
    // Basic calculation: 35ml per kg of body weight
    let target = profile.weightKg * 35;
    
    // Adjust based on activity level
    const activityMultipliers: Record<string, number> = {
      sedentary: 1.0,
      light: 1.1,
      moderate: 1.2,
      active: 1.3,
      very_active: 1.4,
    };
    
    target *= activityMultipliers[profile.activityLevel] || 1.0;
    
    setProfile({ ...profile, dailyTargetMl: Math.round(target) });
  };

  const handleSave = () => {
    if (profile) {
      StorageService.saveProfile(profile);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      window.dispatchEvent(new CustomEvent('profileUpdated'));
    }
  };

  if (!profile) return null;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-gray-900 dark:text-white mb-2">Profile Settings</h1>
        <p className="text-gray-600 dark:text-gray-400">Customize your hydration goals</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <div className="space-y-6">
          {/* Name */}
          <div>
            <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
              Name
            </label>
            <input
              type="text"
              value={profile.name}
              onChange={(e) => setProfile({ ...profile, name: e.target.value })}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
            />
          </div>

          {/* Age and Weight */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
                Age
              </label>
              <input
                type="number"
                value={profile.age}
                onChange={(e) => setProfile({ ...profile, age: parseInt(e.target.value) })}
                className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
                min="1"
                max="120"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
                Weight (kg)
              </label>
              <input
                type="number"
                value={profile.weightKg}
                onChange={(e) => setProfile({ ...profile, weightKg: parseFloat(e.target.value) })}
                className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
                min="1"
                step="0.1"
              />
            </div>
          </div>

          {/* Activity Level */}
          <div>
            <label className="block text-sm text-gray-700 dark:text-gray-300 mb-3">
              Activity Level
            </label>
            <div className="space-y-2">
              {activityLevels.map((level) => (
                <label
                  key={level.value}
                  className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
                    profile.activityLevel === level.value
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                  }`}
                >
                  <input
                    type="radio"
                    name="activityLevel"
                    value={level.value}
                    checked={profile.activityLevel === level.value}
                    onChange={(e) => setProfile({ ...profile, activityLevel: e.target.value })}
                    className="w-4 h-4 text-blue-500"
                  />
                  <div className="flex-1">
                    <p className="text-gray-900 dark:text-white">{level.label}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{level.description}</p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Daily Target */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm text-gray-700 dark:text-gray-300">
                Daily Target (ml)
              </label>
              <button
                onClick={calculateTarget}
                className="text-sm text-blue-500 hover:text-blue-600 transition-colors"
              >
                Auto Calculate
              </button>
            </div>
            <input
              type="number"
              value={profile.dailyTargetMl}
              onChange={(e) => setProfile({ ...profile, dailyTargetMl: parseInt(e.target.value) })}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
              min="500"
              max="10000"
              step="100"
            />
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              Recommended: {Math.round(profile.weightKg * 35)} ml based on your weight
            </p>
          </div>

          {/* Save Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSave}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white py-4 rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all duration-300 hover:shadow-2xl"
          >
            <Save className="w-5 h-5" />
            {saved ? 'Saved!' : 'Save Changes'}
          </motion.button>
        </div>
      </motion.div>

      {/* Info Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 dark:from-blue-500/20 dark:to-cyan-500/20 backdrop-blur-xl rounded-3xl p-6 border border-blue-200 dark:border-blue-700"
      >
        <h3 className="text-gray-900 dark:text-white mb-3">📊 How we calculate your target</h3>
        <p className="text-gray-700 dark:text-gray-300 text-sm">
          We use a formula based on your body weight (35ml per kg) and adjust it according to your activity level. 
          More active individuals need more water to stay properly hydrated.
        </p>
      </motion.div>
    </div>
  );
}
