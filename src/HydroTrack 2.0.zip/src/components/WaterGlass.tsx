import { motion } from 'motion/react';

interface WaterGlassProps {
  percentage: number;
}

export function WaterGlass({ percentage }: WaterGlassProps) {
  const clampedPercentage = Math.min(Math.max(percentage, 0), 100);

  return (
    <div className="relative w-48 h-64 mx-auto">
      {/* Glass Container */}
      <div className="absolute inset-0 flex items-end justify-center">
        <svg
          viewBox="0 0 200 280"
          className="w-full h-full"
          style={{ filter: 'drop-shadow(0 10px 30px rgba(0, 0, 0, 0.2))' }}
        >
          {/* Glass outline with 3D effect */}
          <defs>
            <linearGradient id="glassGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(255, 255, 255, 0.4)" />
              <stop offset="50%" stopColor="rgba(255, 255, 255, 0.1)" />
              <stop offset="100%" stopColor="rgba(255, 255, 255, 0.3)" />
            </linearGradient>
            <linearGradient id="waterGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#60a5fa" />
              <stop offset="100%" stopColor="#3b82f6" />
            </linearGradient>
          </defs>
          
          {/* Glass body */}
          <path
            d="M 60 20 L 50 260 L 150 260 L 140 20 Z"
            fill="url(#glassGradient)"
            stroke="rgba(148, 163, 184, 0.5)"
            strokeWidth="3"
          />
          
          {/* Water with wave animation */}
          <motion.g
            initial={{ y: 280 }}
            animate={{ y: 280 - (clampedPercentage * 2.4) }}
            transition={{ type: 'spring', stiffness: 50, damping: 20 }}
          >
            <path
              d="M 50 0 L 50 240 L 150 240 L 150 0 Q 125 -10 100 0 T 50 0 Z"
              fill="url(#waterGradient)"
              opacity="0.8"
            >
              <animate
                attributeName="d"
                dur="3s"
                repeatCount="indefinite"
                values="
                  M 50 0 L 50 240 L 150 240 L 150 0 Q 125 -10 100 0 T 50 0 Z;
                  M 50 0 L 50 240 L 150 240 L 150 0 Q 125 10 100 0 T 50 0 Z;
                  M 50 0 L 50 240 L 150 240 L 150 0 Q 125 -10 100 0 T 50 0 Z;
                "
              />
            </path>
            
            {/* Bubbles */}
            {[...Array(5)].map((_, i) => (
              <motion.circle
                key={i}
                cx={70 + i * 15}
                cy={200}
                r="3"
                fill="rgba(255, 255, 255, 0.5)"
                initial={{ y: 0, opacity: 0.5 }}
                animate={{ 
                  y: [-40, -80, -120],
                  opacity: [0.5, 0.3, 0]
                }}
                transition={{
                  duration: 2 + i * 0.5,
                  repeat: Infinity,
                  delay: i * 0.3,
                }}
              />
            ))}
          </motion.g>
          
          {/* Highlight effect */}
          <ellipse
            cx="75"
            cy="100"
            rx="15"
            ry="40"
            fill="rgba(255, 255, 255, 0.3)"
          />
        </svg>
      </div>
      
      {/* Percentage display */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="text-5xl text-gray-900 dark:text-white drop-shadow-lg"
        >
          {Math.round(clampedPercentage)}%
        </motion.div>
      </div>
    </div>
  );
}
