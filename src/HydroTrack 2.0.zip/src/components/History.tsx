import { useState, useEffect } from 'react';
import { Calendar, Droplets, Trash2, TrendingUp, BarChart3 } from 'lucide-react';
import { StorageService } from '../services/StorageService';
import { motion } from 'motion/react';

interface HistoryProps {
  userId: string;
}

export function History({ userId }: HistoryProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [entries, setEntries] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    loadEntries();
  }, [userId, selectedDate]);

  const loadEntries = () => {
    const startDate = new Date(selectedDate);
    startDate.setHours(0, 0, 0, 0);
    const endDate = new Date(selectedDate);
    endDate.setHours(23, 59, 59, 999);

    const allEntries = StorageService.getEntries(userId, {
      start: startDate.toISOString(),
      end: endDate.toISOString(),
    });

    setEntries(allEntries);

    // Calculate stats
    const totalMl = allEntries.reduce((sum, entry) => sum + entry.amountMl, 0);
    const profile = StorageService.getProfile(userId);
    const percentage = profile ? (totalMl / profile.dailyTargetMl) * 100 : 0;

    setStats({
      totalMl,
      count: allEntries.length,
      percentage: Math.round(percentage),
      target: profile?.dailyTargetMl || 0,
    });
  };

  const deleteEntry = (entryId: string) => {
    if (confirm('Are you sure you want to delete this entry?')) {
      const allEntries = StorageService.getAllEntries();
      const filtered = allEntries.filter((e: any) => e.id !== entryId);
      localStorage.setItem('water_entries', JSON.stringify(filtered));
      loadEntries();
    }
  };

  const goToToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-gray-900 dark:text-white mb-2">History</h1>
        <p className="text-gray-600 dark:text-gray-400">View your past water intake</p>
      </motion.div>

      {/* Date Selector */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <div className="flex items-center gap-4">
          <Calendar className="w-6 h-6 text-blue-500" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            max={new Date().toISOString().split('T')[0]}
            className="flex-1 px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
          />
          <button
            onClick={goToToday}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-400 text-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
          >
            Today
          </button>
        </div>
      </motion.div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-blue-500 to-cyan-400 rounded-3xl p-6 shadow-2xl text-white"
          >
            <Droplets className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">{stats.totalMl} ml</p>
            <p className="text-sm text-white/80">Total Intake</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-purple-500 to-pink-400 rounded-3xl p-6 shadow-2xl text-white"
          >
            <BarChart3 className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">{stats.count}</p>
            <p className="text-sm text-white/80">Times Hydrated</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-green-500 to-teal-400 rounded-3xl p-6 shadow-2xl text-white"
          >
            <TrendingUp className="w-8 h-8 mb-3 opacity-80" />
            <p className="text-3xl mb-1">{stats.percentage}%</p>
            <p className="text-sm text-white/80">Goal Progress</p>
          </motion.div>
        </div>
      )}

      {/* Entries List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-6 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <h2 className="text-gray-900 dark:text-white mb-4">Entries</h2>
        
        {entries.length === 0 ? (
          <div className="text-center py-12">
            <Droplets className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400">No entries for this date</p>
          </div>
        ) : (
          <div className="space-y-3">
            {entries.map((entry, index) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 + index * 0.05 }}
                className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-2xl hover:shadow-lg transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
                  <Droplets className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-gray-900 dark:text-white">{entry.amountMl} ml</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {new Date(entry.timestamp).toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                  {entry.note && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 italic mt-1 truncate">
                      "{entry.note}"
                    </p>
                  )}
                </div>
                <button
                  onClick={() => deleteEntry(entry.id)}
                  className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
}
