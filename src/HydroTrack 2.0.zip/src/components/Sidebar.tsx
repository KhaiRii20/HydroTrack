import { Home, User, Droplets, Bell, History, Settings, Moon, Sun, Waves, Sunset, Menu, X } from 'lucide-react';
import { useTheme } from './ThemeProvider';
import { motion, AnimatePresence } from 'motion/react';

interface SidebarProps {
  currentView: string;
  onViewChange: (view: any) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export function Sidebar({ currentView, onViewChange, isOpen, onToggle }: SidebarProps) {
  const { theme, setTheme } = useTheme();

  const menuItems = [
    { id: 'dashboard', icon: Home, label: 'Dashboard' },
    { id: 'tracker', icon: Droplets, label: 'Add Water' },
    { id: 'history', icon: History, label: 'History' },
    { id: 'reminders', icon: Bell, label: 'Reminders' },
    { id: 'profile', icon: User, label: 'Profile' },
  ];

  const themes = [
    { id: 'light', icon: Sun, label: 'Light', color: 'text-yellow-500' },
    { id: 'dark', icon: Moon, label: 'Dark', color: 'text-indigo-500' },
    { id: 'ocean', icon: Waves, label: 'Ocean', color: 'text-cyan-500' },
    { id: 'sunset', icon: Sunset, label: 'Sunset', color: 'text-orange-500' },
  ];

  return (
    <>
      {/* Mobile Toggle Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5 }}
        onClick={onToggle}
        className="fixed top-6 left-6 z-50 lg:hidden w-12 h-12 bg-white dark:bg-gray-800 rounded-xl shadow-lg flex items-center justify-center text-gray-900 dark:text-white hover:scale-110 transition-transform"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </motion.button>

      {/* Desktop Toggle Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.5 }}
        onClick={onToggle}
        className="hidden lg:block fixed top-6 left-6 z-50 w-12 h-12 bg-white dark:bg-gray-800 rounded-xl shadow-lg flex items-center justify-center text-gray-900 dark:text-white hover:scale-110 transition-transform"
        style={{ left: isOpen ? '276px' : '24px' }}
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </motion.button>

      {/* Overlay for mobile */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onToggle}
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence>
        {isOpen && (
          <motion.aside
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed lg:relative w-72 h-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl border-r border-gray-200 dark:border-gray-700 flex flex-col shadow-2xl z-40"
          >
            {/* Logo */}
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="p-6 border-b border-gray-200 dark:border-gray-700 pt-20 lg:pt-6"
            >
              <div className="flex items-center gap-3">
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl flex items-center justify-center shadow-lg"
                  style={{ transform: 'perspective(500px) rotateY(-10deg)' }}
                >
                  <Droplets className="w-7 h-7 text-white" />
                </motion.div>
                <div>
                  <h1 className="text-gray-900 dark:text-white">HydroTrack</h1>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Stay Hydrated</p>
                </div>
              </div>
            </motion.div>

            {/* Navigation */}
            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
              {menuItems.map((item, index) => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                
                return (
                  <motion.button
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    onClick={() => {
                      onViewChange(item.id);
                      // Close sidebar on mobile after selection
                      if (window.innerWidth < 1024) {
                        onToggle();
                      }
                    }}
                    whileHover={{ scale: 1.05, x: 5 }}
                    whileTap={{ scale: 0.95 }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                      isActive
                        ? 'bg-gradient-to-r from-blue-500 to-cyan-400 text-white shadow-lg shadow-blue-500/30'
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700/50'
                    }`}
                    style={isActive ? { transform: 'perspective(500px) translateZ(10px)' } : {}}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </motion.button>
                );
              })}
            </nav>

            {/* Theme Selector */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="p-4 border-t border-gray-200 dark:border-gray-700"
            >
              <div className="mb-3 text-xs text-gray-500 dark:text-gray-400 px-2">Theme</div>
              <div className="grid grid-cols-2 gap-2">
                {themes.map((t, index) => {
                  const Icon = t.icon;
                  return (
                    <motion.button
                      key={t.id}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.9 + index * 0.05 }}
                      onClick={() => setTheme(t.id as any)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`flex flex-col items-center gap-1 p-3 rounded-xl transition-all duration-300 ${
                        theme === t.id
                          ? 'bg-gray-100 dark:bg-gray-700 shadow-lg'
                          : 'hover:bg-gray-50 dark:hover:bg-gray-700/50'
                      }`}
                    >
                      <Icon className={`w-5 h-5 ${theme === t.id ? t.color : 'text-gray-400'}`} />
                      <span className="text-xs text-gray-600 dark:text-gray-400">{t.label}</span>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}