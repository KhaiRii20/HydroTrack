import { useState, useEffect } from 'react';
import { Bell, Plus, Trash2, Clock } from 'lucide-react';
import { StorageService } from '../services/StorageService';
import { motion } from 'motion/react';

interface ReminderSettingsProps {
  userId: string;
}

export function ReminderSettings({ userId }: ReminderSettingsProps) {
  const [settings, setSettings] = useState<any>(null);
  const [newTime, setNewTime] = useState('09:00');

  useEffect(() => {
    loadSettings();
  }, [userId]);

  const loadSettings = () => {
    let loadedSettings = StorageService.getReminderSettings(userId);
    if (!loadedSettings) {
      loadedSettings = {
        id: crypto.randomUUID(),
        userId,
        mode: 'interval',
        intervalMin: 60,
        fixedTimes: ['09:00', '12:00', '15:00', '18:00', '21:00'],
        enabled: true,
      };
      StorageService.saveReminderSettings(loadedSettings);
    }
    setSettings(loadedSettings);
  };

  const handleSave = () => {
    if (settings) {
      StorageService.saveReminderSettings(settings);
      alert('Reminder settings saved!');
    }
  };

  const addFixedTime = () => {
    if (settings && newTime && !settings.fixedTimes.includes(newTime)) {
      const updatedSettings = {
        ...settings,
        fixedTimes: [...settings.fixedTimes, newTime].sort(),
      };
      setSettings(updatedSettings);
      StorageService.saveReminderSettings(updatedSettings);
      setNewTime('09:00');
    }
  };

  const removeFixedTime = (time: string) => {
    if (settings) {
      const updatedSettings = {
        ...settings,
        fixedTimes: settings.fixedTimes.filter((t: string) => t !== time),
      };
      setSettings(updatedSettings);
      StorageService.saveReminderSettings(updatedSettings);
    }
  };

  if (!settings) return null;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-gray-900 dark:text-white mb-2">Reminder Settings</h1>
        <p className="text-gray-600 dark:text-gray-400">Set up notifications to stay hydrated</p>
      </motion.div>

      {/* Enable/Disable */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl flex items-center justify-center shadow-lg">
              <Bell className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-gray-900 dark:text-white">Reminders</h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {settings.enabled ? 'Enabled' : 'Disabled'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              const updated = { ...settings, enabled: !settings.enabled };
              setSettings(updated);
              StorageService.saveReminderSettings(updated);
            }}
            className={`relative w-16 h-8 rounded-full transition-colors duration-300 ${
              settings.enabled ? 'bg-blue-500' : 'bg-gray-300 dark:bg-gray-600'
            }`}
          >
            <motion.div
              animate={{ x: settings.enabled ? 32 : 0 }}
              className="absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-lg"
            />
          </button>
        </div>
      </motion.div>

      {/* Reminder Mode */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
      >
        <h2 className="text-gray-900 dark:text-white mb-6">Reminder Mode</h2>
        <div className="space-y-3">
          <label
            className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
              settings.mode === 'interval'
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
          >
            <input
              type="radio"
              name="mode"
              value="interval"
              checked={settings.mode === 'interval'}
              onChange={(e) => setSettings({ ...settings, mode: e.target.value })}
              className="w-4 h-4 text-blue-500"
            />
            <Clock className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            <div className="flex-1">
              <p className="text-gray-900 dark:text-white">Interval</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Remind me every X minutes</p>
            </div>
          </label>

          <label
            className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 ${
              settings.mode === 'fixed_times'
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
            }`}
          >
            <input
              type="radio"
              name="mode"
              value="fixed_times"
              checked={settings.mode === 'fixed_times'}
              onChange={(e) => setSettings({ ...settings, mode: e.target.value })}
              className="w-4 h-4 text-blue-500"
            />
            <Bell className="w-5 h-5 text-gray-600 dark:text-gray-400" />
            <div className="flex-1">
              <p className="text-gray-900 dark:text-white">Fixed Times</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Remind me at specific times</p>
            </div>
          </label>
        </div>
      </motion.div>

      {/* Interval Settings */}
      {settings.mode === 'interval' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
        >
          <h2 className="text-gray-900 dark:text-white mb-4">Interval Settings</h2>
          <div>
            <label className="block text-sm text-gray-700 dark:text-gray-300 mb-2">
              Remind me every (minutes)
            </label>
            <input
              type="number"
              value={settings.intervalMin}
              onChange={(e) => setSettings({ ...settings, intervalMin: parseInt(e.target.value) })}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
              min="15"
              max="480"
              step="15"
            />
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
              Recommended: 60-120 minutes
            </p>
          </div>
        </motion.div>
      )}

      {/* Fixed Times Settings */}
      {settings.mode === 'fixed_times' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-gray-200 dark:border-gray-700"
        >
          <h2 className="text-gray-900 dark:text-white mb-4">Fixed Times</h2>
          
          {/* Add new time */}
          <div className="flex gap-2 mb-4">
            <input
              type="time"
              value={newTime}
              onChange={(e) => setNewTime(e.target.value)}
              className="flex-1 px-4 py-3 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-xl text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={addFixedTime}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-cyan-400 text-white rounded-xl shadow-lg flex items-center gap-2 transition-all duration-300"
            >
              <Plus className="w-5 h-5" />
              Add
            </motion.button>
          </div>

          {/* Time list */}
          <div className="space-y-2">
            {settings.fixedTimes.map((time: string) => (
              <motion.div
                key={time}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-xl"
              >
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-blue-500" />
                  <span className="text-gray-900 dark:text-white text-lg">{time}</span>
                </div>
                <button
                  onClick={() => removeFixedTime(time)}
                  className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Info */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 dark:from-yellow-500/20 dark:to-orange-500/20 backdrop-blur-xl rounded-3xl p-6 border border-yellow-200 dark:border-yellow-700"
      >
        <h3 className="text-gray-900 dark:text-white mb-3">⚠️ Browser Notifications</h3>
        <p className="text-gray-700 dark:text-gray-300 text-sm">
          This is a demo app. For real browser notifications, you would need to implement the Web Notifications API 
          and handle permission requests. The settings are saved and can be used to trigger actual notifications 
          in a production environment.
        </p>
      </motion.div>
    </div>
  );
}
