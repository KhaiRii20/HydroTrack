export class StorageService {
  static saveProfile(profile: any) {
    localStorage.setItem(`user_profile_${profile.id}`, JSON.stringify(profile));
  }

  static getProfile(userId: string): any {
    const data = localStorage.getItem(`user_profile_${userId}`);
    return data ? JSON.parse(data) : null;
  }

  static saveEntry(entry: any) {
    const entries = this.getAllEntries();
    entries.push(entry);
    localStorage.setItem('water_entries', JSON.stringify(entries));
  }

  static getAllEntries(): any[] {
    const data = localStorage.getItem('water_entries');
    return data ? JSON.parse(data) : [];
  }

  static getEntries(userId: string, dateRange: { start: string; end: string }): any[] {
    const entries = this.getAllEntries();
    return entries.filter((entry: any) => {
      const timestamp = new Date(entry.timestamp);
      const start = new Date(dateRange.start);
      const end = new Date(dateRange.end);
      return entry.userId === userId && timestamp >= start && timestamp <= end;
    });
  }

  static saveReminderSettings(settings: any) {
    localStorage.setItem(`reminder_settings_${settings.userId}`, JSON.stringify(settings));
  }

  static getReminderSettings(userId: string): any {
    const data = localStorage.getItem(`reminder_settings_${userId}`);
    return data ? JSON.parse(data) : null;
  }

  static getCurrentUserId(): string | null {
    return localStorage.getItem('current_user_id');
  }

  static setCurrentUserId(userId: string) {
    localStorage.setItem('current_user_id', userId);
  }
}
