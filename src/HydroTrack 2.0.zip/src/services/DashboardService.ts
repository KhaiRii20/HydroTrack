import { StorageService } from './StorageService';

export class DashboardService {
  static getDailySummary(userId: string, date: string) {
    const startDate = new Date(date);
    startDate.setHours(0, 0, 0, 0);
    const endDate = new Date(date);
    endDate.setHours(23, 59, 59, 999);

    const entries = StorageService.getEntries(userId, {
      start: startDate.toISOString(),
      end: endDate.toISOString(),
    });

    const totalMl = entries.reduce((sum, entry) => sum + entry.amountMl, 0);
    const recentEntries = entries.slice(-5).reverse();

    return {
      totalMl,
      entries: entries.length,
      recentEntries,
    };
  }

  static getWeeklySummary(userId: string) {
    const endDate = new Date();
    endDate.setHours(23, 59, 59, 999);
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 7);
    startDate.setHours(0, 0, 0, 0);

    const entries = StorageService.getEntries(userId, {
      start: startDate.toISOString(),
      end: endDate.toISOString(),
    });

    const profile = StorageService.getProfile(userId);
    const dailyTarget = profile?.dailyTargetMl || 2000;

    // Group entries by date
    const entriesByDate: Record<string, number> = {};
    entries.forEach((entry) => {
      const date = new Date(entry.timestamp).toISOString().split('T')[0];
      entriesByDate[date] = (entriesByDate[date] || 0) + entry.amountMl;
    });

    // Count days that met target
    const daysMetTarget = Object.values(entriesByDate).filter(
      (total) => total >= dailyTarget
    ).length;

    // Calculate average
    const totalMl = entries.reduce((sum, entry) => sum + entry.amountMl, 0);
    const avgMl = entries.length > 0 ? Math.round(totalMl / 7) : 0;

    return {
      avgMl,
      daysMetTarget,
      totalMl,
    };
  }
}
