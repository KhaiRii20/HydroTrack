import { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { ProfileSettings } from './components/ProfileSettings';
import { ConsumptionTracker } from './components/ConsumptionTracker';
import { ReminderSettings } from './components/ReminderSettings';
import { History } from './components/History';
import { Sidebar } from './components/Sidebar';
import { ThemeProvider } from './components/ThemeProvider';
import { SplashScreen } from './components/SplashScreen';
import { StorageService } from './services/StorageService';

type View = 'dashboard' | 'profile' | 'tracker' | 'reminders' | 'history';

export default function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [showSplash, setShowSplash] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [userId] = useState(() => {
    const stored = StorageService.getCurrentUserId();
    if (stored) return stored;
    const newId = crypto.randomUUID();
    StorageService.setCurrentUserId(newId);
    return newId;
  });

  useEffect(() => {
    // Initialize user profile if not exists
    const profile = StorageService.getProfile(userId);
    if (!profile) {
      StorageService.saveProfile({
        id: userId,
        name: 'User',
        age: 25,
        weightKg: 70,
        activityLevel: 'moderate',
        dailyTargetMl: 2000,
      });
    }
  }, [userId]);

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return (
    <ThemeProvider>
      <div className="flex h-screen overflow-hidden bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-gray-900 dark:to-blue-900 transition-colors duration-300">
        <Sidebar 
          currentView={currentView} 
          onViewChange={setCurrentView}
          isOpen={sidebarOpen}
          onToggle={() => setSidebarOpen(!sidebarOpen)}
        />
        
        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          <div className="max-w-7xl mx-auto">
            {currentView === 'dashboard' && <Dashboard userId={userId} />}
            {currentView === 'profile' && <ProfileSettings userId={userId} />}
            {currentView === 'tracker' && <ConsumptionTracker userId={userId} />}
            {currentView === 'reminders' && <ReminderSettings userId={userId} />}
            {currentView === 'history' && <History userId={userId} />}
          </div>
        </main>
      </div>
    </ThemeProvider>
  );
}